from vidgear.gears import CamGear
import uvicorn
from vidgear.gears.asyncio import WebGear_RTC

# create your own custom streaming class
class Custom_Stream_Class:
    """
    Custom Streaming
    """
    def __init__(self, source1=None, save_queue=None):
        self.source = source1
        if self.source is None:
            raise ValueError("Provide both source")
        self.stream= CamGear(source=self.source).start() 
        self.running = True
        self.save_queue = save_queue

    def read(self):
        if self.stream is None:
            return None
        # check if we're still running
        if self.running:
            # read video frame
            frame = self.stream.read()
            # putting to queue
            self.save_queue.put(frame)
            return frame
        return None

    def stop(self):
        self.running = False
        # close stream
        if not (self.stream is None):
            self.stream.stop()
            self.stream = None

    # Reconnecting stream when error occuring
    def reload(self):
        self.stream.stop()
        print('Reconnecting to RTSP camera...!')
        self.stream= CamGear(source=self.source).start()

# streaming to web app
def start_streaming(port, custom_stream):
    options = {
    "custom_data_location": "./",
    "custom_stream": custom_stream,
    }
    # initialize WebGear_RTC app without any source
    web = WebGear_RTC(logging=True, **options)
    # run this app on Uvicorn server at address http://localhost:8000/
    uvicorn.run(web(), host="localhost", port=port)
    web.shutdown()