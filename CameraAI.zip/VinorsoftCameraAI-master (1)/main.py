
from multiprocessing import Process
from threading import Thread
from queue import Queue
from do_streaming import *
from save_to_disk import *

def do_process(data):
    rtsp, port = data
    save_queue = Queue()
    custom_stream = Custom_Stream_Class(source1= rtsp, save_queue = save_queue)
    # save frames to disk thread
    save_thread = Thread(target=save_stream, args=(save_queue, port,))
    save_thread.daemon = True
    save_thread.start()
    # streaming to web app thread
    stream_thread = Thread(target=start_streaming, args=(port, custom_stream,))
    stream_thread.start()
    stream_thread.join()

if __name__ == '__main__':
    rtsps = ['rtsp://admin:Password123@mbamc-eco.cameraddns.net:12222/Streaming/Channels/101', 
    'rtsp://admin:Password123@cameranamkhang.cameraddns.net:554/Streaming/Channels/101',
    'rtsp://admin:Password123@mbamc-eco-1.cameraddns.net:12223/Streaming/Channels/101',
    'rtsp://admin:Password123@mbamc-adg3.cameraddns.net:12224/Streaming/Channels/101']
    ports = [8555,8556,8557,8558]
    processes = []
    for data in zip(rtsps, ports):
        p = Process(target=do_process, args=(data,))
        processes.append(p)
        p.start()
    for proc in processes:
        proc.join()