## Requirements
```
Python3.6 will raise errors, I try with python3.9 successfully
```
## Installation
```
pip3 install opencv-python uvicorn starlette Jinja2 flask
sudo apt install libavdevice-dev libavfilter-dev libopus-dev libvpx-dev pkg-config libsrtp2-dev
pip3 install aiortc
pip3 install uvloop
pip3 install -U vidgear[asyncio] 
If you use Zsh, please try this: pip3 install -U 'vidgear[asyncio]'
```
## How to run 

```
python3 main.py
python3 view_flask.py
# Open browsers at port: localhost:5555
```