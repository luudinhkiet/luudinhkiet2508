var iframe = document.getElementById("iframe");
var div = document.getElementById("PlaceToPutTable");
div.innerHTML = iframe.contentWindow.document.getElementById("my_container").innerHTML;