var button_ai = document.getElementById("button-ai");
var sublink_ai = document.getElementById("sublink-ai");
var iframe1 = document.getElementsById("iframe1");
function myFunction(event) {
    // event.target.classList.toggle("active");
    // if (event.target.classList.contains("active")) {
    //     alert("active");
    // } else {
    //     alert("not active");
    // }
}
// function setIframe1() {
//     iframe1
// }
function handleToggleAI(event) {}
document.addEventListener("click", myFunction);
// button_ai.addEventListener("click", handleToggleAI);
