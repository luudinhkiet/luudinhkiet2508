import time

# save stream
def save_stream(save_queue, port, sleep_seconds=2):
    while True:
        if save_queue.not_empty:
            frame = save_queue.get()
            ## do something here
            print("PORT {0} - Resolution {1}".format(port, frame.shape))
            
        else:
            print('Sleeping {0} seconds'.format(sleep_seconds))
            time.sleep(sleep_seconds)